
<?php $__env->startSection('title',"Forgot Password"); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content d-flex align-items-center justify-content-center">
 
  <div class="row w-100 mx-0 auth-page">
    <div class="col-md-6 col-xl-4 mx-auto">
      <div class="card">
      
        <div class="row">
          
          <div class="col-md-12 ps-md-0">
          <form method="POST" action="<?php echo e(route('password.email')); ?>">
          <?php echo csrf_field(); ?>
            <div class="auth-form-wrapper px-4 py-5">
              <a href="#" class="noble-ui-logo d-block mb-2 text-center">IdealBet</a>
              <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
            <?php else: ?>
              <?php if(session('status')): ?>
              <h5 class="text-muted fw-normal mb-4 text-center alert alert-success"><?php echo e(session('status')); ?> <?php echo e('Please check your email.'); ?></h5>
              <?php else: ?>
              <h5 class="text-muted fw-normal mb-4 text-center" style="font-size: 12px;">Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one.</h5>
              <?php endif; ?>
             <?php endif; ?>
              <form class="forms-sample">
                <div class="mb-3">
                  <label for="userEmail" class="form-label">Email</label>
                  <input type="email"  name="email" class="form-control" id="userEmail" placeholder="Email" required>
                </div>
             
                <div class="mt-3">
                            <input type="submit" class="btn btn-primary w-100 waves-effect waves-light" value="Email Password Reset Link">
                        </div>
                <a href="<?php echo e(route('login')); ?>" class="d-block mt-3 text-muted">Back to Login</a>
              </form>
            </div>
        </form>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Game\idealbet\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>