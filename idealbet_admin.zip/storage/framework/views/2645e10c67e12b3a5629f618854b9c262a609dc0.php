
<?php $__env->startSection('title',"Home"); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-3 ">
    </div>
    <div class="col-md-6 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <h6 class="card-title col">Cahnge Password</h6>
                </div>
            
                <form class="forms-sample changePassword_form" method="POST" id="changePassword_form" >
                <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="mb-3">
                            <label for="" class="form-label">Old password</label>
                            <input type="password" class="form-control" name='oldpassword' id="oldpassword" placeholder="Old Password">
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" name='password' id="password"  placeholder="Password">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Confirm Password</label>
                            <input type="password" class="form-control" name='confirmpassword' id="confirmpassword" placeholder="Confirm Password">
                        </div>
                        <div class="">
                            <button class="btn btn-primary submit_cahngePassword" type="button">Save</button>
                        </div>
                    <div>
                </form>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 ">
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('plugin-scripts'); ?>
<script src="<?php echo e(asset('assets/js/jquery.validate.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
<script src="<?php echo e(asset('assets/js/custome/changePassword/change-password.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Game\idealbet\resources\views/changePassword.blade.php ENDPATH**/ ?>