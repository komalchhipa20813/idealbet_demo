<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between px-4 py-3 border-top small">
  <p class="text-muted mb-1 mb-md-0"></p>
  <p class="text-muted">Copyright © 2023 <a href="https://irss.tk/" target="_blank">Alita Infotech Pvt. Ltd.</a></p>
</footer>
<?php /**PATH D:\Work\Game\idealbet\resources\views/layouts/footer.blade.php ENDPATH**/ ?>