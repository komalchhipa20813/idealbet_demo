
<?php $__env->startSection('title',"Home Section"); ?>
<?php $__env->startPush('plugin-styles'); ?>
  <link href="<?php echo e(asset('assets/plugins/simplemde/simplemde.min.css')); ?>" rel="stylesheet" />
  
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<nav class="page-breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home Sections</a></li>
   
  </ol>
</nav>

<div class="row">
  <div class="col-md-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="row">
          <h6 class="card-title col">Home Sections</h6>
        </div>

        <form class="forms-sample section_form" method="POST" name="registration" id="sections_form">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="section_id" class="section_id" id="section_id" value="<?php echo e((!empty($data['sections'])) ? encryptid($data['sections']->id) : encryptid('0')); ?>">
          <div class="row">
            <div class="col-md-12">
              <div class="mb-12">
                  <label for="branch" class="  control-label">Section - 1 </label>
                  <textarea class="ckeditor form-control" name="section1" id="section1"><?php echo e((!empty($data['sections'])) ? $data['sections']->section1 : ''); ?></textarea>
              </div>
            </div>
            <div class="col-md-12">
              <div class="mb-12">
                  <label for="branch" class="  control-label">Section - 2 </label>
                  <textarea class="ckeditor form-control" name="section2" id="section2"><?php echo e((!empty($data['sections'])) ? $data['sections']->section2 : ''); ?></textarea>
              </div>
            </div>
            <div class="col-md-12">
              <div class="mb-12">
                  <label for="branch" class="  control-label">Section - 3 </label>
                  <textarea class="ckeditor form-control" name="section3" id="section3"><?php echo e((!empty($data['sections'])) ? $data['sections']->section3 : ''); ?></textarea>
              </div>
            </div>
            <div class="col-md-12">
              <div class="mb-12">
                  <label for="branch" class="  control-label">Section - 4 </label>
                  <textarea class="ckeditor form-control" name="section4" id="section4"><?php echo e((!empty($data['sections'])) ? $data['sections']->section4 : ''); ?></textarea>
              </div>
            </div>
            <div class="col-md-12">
              <div class="mb-12">
                  <label for="branch" class="  control-label">Section - 5 </label>
                  <textarea class="ckeditor form-control" name="section5" id="section5"><?php echo e((!empty($data['sections'])) ? $data['sections']->section5 : ''); ?></textarea>
              </div>
            </div>
            <div class="" style="padding-top: 10px;">
              <button class="btn btn-primary submit_section" data-type="section1" type="button">Save</button>
            </div>
          </div>
        </form>


        
       
       
       
      
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('plugin-scripts'); ?>
<script src="https://cdn.ckeditor.com/4.22.1/standard/ckeditor.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>

  <script src="<?php echo e(asset('assets/js/custome/home/sections.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Game\idealbet\resources\views/sections.blade.php ENDPATH**/ ?>