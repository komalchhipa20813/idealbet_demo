<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Work\Game\idealbet\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>